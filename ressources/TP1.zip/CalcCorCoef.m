function [CorCoef Moy1 Moy2 Ecart1 Ecart2]= CalcCorCoef(Bout1,Bout2)

% Calcul des moyennes et écart-types
	Moy1 = mean(Bout1);
	Moy2 = mean(Bout2);
	Ecart1 = std(Bout1);
	Ecart2 = std(Bout2);

% Calcul du coefficient de corrélation (sans la toolbox qui irait...)
	CorCoef = mean(  (Bout1-mean(Bout1))/Ecart1 .* (Bout2-mean(Bout2))/Ecart2  );






