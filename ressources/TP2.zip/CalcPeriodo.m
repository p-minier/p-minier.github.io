function [NuGrid Periodo] = CalcPeriodo(Signal)

% Paramètres de taille de signaux
	Taille = length(Signal);

% Calcul du Périodogramme
	TailleSpectrale = 4*Taille;
	Periodo = abs( fft( Signal , TailleSpectrale )  ).^2;
	Periodo = fftshift(Periodo) / Taille;

% Calcul de la grille fréquentielle
	NuGrid = linspace(-0.5,0.5,TailleSpectrale)';


