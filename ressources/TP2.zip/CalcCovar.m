function [Temps CorrelEmpirique] = CalcCorrel(Signal)

% Paramètres de taille de signaux
	Taille = length(Signal);
	Temps = (-Taille+1 :Taille-1)';

% Calcul de la corrélation empirique (sans toolbox "xcorr")
	TailleSpectrale = 2*Taille-1;
	Periodo = abs( fft( Signal , TailleSpectrale )  ).^2;
	Periodo = Periodo / Taille;
	CorrelEmpirique = fftshift(ifft(Periodo));

% Calcul de la corrélation empirique
	%CorrelEmpiriqueBis = xcorr(Signal,'biased');
	%figure(12),clf
	%plot([CorrelEmpirique CorrelEmpiriqueBis+0.1])

