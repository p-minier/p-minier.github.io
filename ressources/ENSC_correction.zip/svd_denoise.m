% TP ENSC 1A
% PM edit: 13/05/2025
function sig_denoised = svd_denoise(sig_b, r)
    % Débruitage d'un signal par SVD de matrice de Hankel
    % sig_b : signal bruité
    % r : rang de troncature (ex: 1 pour sinusoïde)
    
    L = round(length(sig_b)/2);
    K = length(sig_b) - L + 1;
    H = hankel(sig_b(1:L), sig_b(L:end));
    
    [U, S, V] = svd(H, 'econ');
    Hf = U(:,1:r) * S(1:r,1:r) * V(:,1:r)';
    
    sig_denoised = zeros(1, length(sig_b));
    count = zeros(1, length(sig_b));
    for i = 1:L
        for j = 1:K
            sig_denoised(i+j-1) = sig_denoised(i+j-1) + Hf(i,j);
            count(i+j-1) = count(i+j-1) + 1;
        end
    end
    sig_denoised = sig_denoised ./ count;
end
