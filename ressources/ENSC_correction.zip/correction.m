% TP ENSC 1A
% PM last edit: 14/05/2025
% Elements de corrections pour le TP

%% Initialisation
clc, clear, close all

% Définition des constantes
fr = [440, 460, 2500];   % fréquences des raies en Hz
Alpha = [1.2, 1.2, 0.6]; % amplitude des raies
Fe = 1e4;    % fréquence d'échantillonnage en Hz
Phi = 0.27;  % phase à l'origine
N = 1024;    % nombre total d'échantillons

%% == Partie 1: Simulation de signaux == %%
% Création du signal
TpsD = (0:N-1).';
TpsP = TpsD / Fe;
Sig = Alpha(1) * sin(2*pi*(fr(1)*TpsP+Phi));

% Check format données
str = ["colonne", "ligne"];
disp("TpsD est une " + str(1+isrow(TpsD)) + ".");
disp("Sig est une " + str(1+isrow(Sig)) + ".");

% Tracé du signal : complet + zoom
figure
Tps = [TpsD, TpsP];
xlabel_ = ["Echantillons", "Temps (s)"];
for i = 1:2
    subplot(2, 2, 2*i-1), plot(Tps(:, i), Sig)
    title("Signal complet")
    grid, xlabel(xlabel_(i)), xlim([0, Tps(end, i)])

    subplot(2, 2, 2*i), plot(Tps(10:100, i), Sig(10:100))
    title("Signal zoomé")
    grid, xlabel(xlabel_(i)), xlim([Tps(10, i), Tps(100, i)])
end
set(gcf, "Position", get(gcf, "Position").*[1, 1, 1.5, 1.5])

% Signal enrichi : ajout des raies 460Hz et 2500Hz d'amplitude moitié
for i = 2:numel(fr)
    Sig = Sig + Alpha(i) * sin(2*pi*(fr(i)*TpsP+Phi));
end

%% == Partie 2.2: Transformée de Fourier ==
% Transformée de Fourier par Fast Fourier Transform (FFT)
M = 32*N;  % nombre de fréquences à évaluer, puissance de 2 préférable
Sig_ft = fftshift(fft(Sig, M));    % recaler [0, 1] vers [-0.5, 0.5]
freq_reduite  = linspace(-0.5, 0.5, M);
freq_physique = freq_reduite * Fe; % conversion en fréquences dimentionnées

% Affichage : réel, imaginaire, module, log10 module
figure
subplot(2, 2, 1); plot(freq_physique, real(Sig_ft));
subplot(2, 2, 2); plot(freq_physique, imag(Sig_ft));
subplot(2, 2, 3); plot(freq_physique, abs(Sig_ft));
subplot(2, 2, 4); plot(freq_physique, log10(abs(Sig_ft)));
title_ = ["Réel", "Imaginaire", "Module", "Log10 Module"];
for i = 1:4
    ax1 = subplot(2, 2, i);
    grid, xlabel("Fréquence (Hz)"), ylabel("Amplitude"), title(title_(i))
    xticks([-Fe/2, -2500, 0, 2500, Fe/2])
end
set(gcf, "Position", get(gcf, "Position").*[1, 1, 2, 2])

% Evaluation de la précision des pics selon M par recherche des max locaux
M_pow = 0:10;
M_list = N*(2.^M_pow);
freq_true = [440, 460, 2500];
N_freq = 3;

% -- recherche des maximums locaux pour chaque M
freq_found = NaN(numel(M_list), N_freq);
for i = 1:numel(M_list)
    M = M_list(i);
    freq = Fe*linspace(-0.5, 0.5, M);
    Sig_ft = fftshift(abs(fft(Sig, M)));  % on travaille sur le module FFT
    maxloc = islocalmax(Sig_ft, "MaxNumExtrema", 2*numel(freq_true));
    freq_max = freq(maxloc);  % on extrait les max
    freq_pos = freq_max(freq_max > 0);  % on conserve les positifs
    freq_found(i, :) = sort(freq_pos);  % on trie
end

% -- affichage selon M des fréquences retrouvées
figure
for i = 1:N_freq
    subplot(2, 2, i)
    hold on
    plot(freq_found(:, i), "-o", "LineWidth", 2)
    yline(freq_true(i), "LineWidth", 1.5)
    ylim([min(min(freq_found(:, i)), freq_true(i)-1), max(max(freq_found(:, i)), freq_true(i)+1)]);
    if i == 1
        legend({"Détecté", "Vraie"}, 'Location', 'best');
    end
    grid, ylabel("Hz"), title("Pic " + num2str(i))
end
sgtitle("Précision des pics retrouvés selon M = log2(Nfft/N)");
set(gcf, "Position", get(gcf, "Position").*[1, 1, 2, 2])

%% == Partie 3: Un peu de son == %%
[Sig_joli, Freq_joli] = audioread("Joli.wav");
PeriodoGlissant(Sig_joli, Freq_joli);
set(gcf, "Position", get(gcf, "Position").*[1, 1, 2, 2])

%% == Partie 4 Un peu de bruit, mais pas trop == %%
Sigma_list = [1, 3, 5];  % liste de sigma à tester
M = 32*N;  % nombre de points pour réaliser la FFT
rank = 5;  % nombre de valeurs propres (issues du signal) à conserver
freq = Fe*linspace(-0.5, 0.5, M);  % fréquences dimentionnées (Hz)

figure
for i = 1:numel(Sigma_list)
    % bruitage du signal
    SigmaBruit = Sigma_list(i);
    Bruit = SigmaBruit * randn(size(Sig));
    Sig_b = Sig + Bruit;

    % calcul du rapport signal à bruit
    RSB = 10*log10(sum(Sig.^2) / sum(Bruit.^2));
    RSB = round(RSB, 3);
    
    % -- affichage
    subplot(numel(Sigma_list), 4, 4*i-3)
    plot(TpsP, Sig_b)
    title("Signal temporel, RSB = " + RSB)
    grid on, xlabel("Temps (s)"), ylabel("Amplitude")

    % fft
    Sig_b_mod = abs(fftshift(fft(Sig_b, M)));

    % -- affichage
    subplot(numel(Sigma_list), 4, 4*i-2)
    plot(freq, Sig_b_mod)
    title("Domaine de Fourier")
    grid on, xlabel("Fréquences (Hz)"), ylabel("Amplitude")

    % debruitage: regarder le fichier svd_denoise.m
    Sig_r = svd_denoise(Sig_b, rank);

    % -- affichage
    subplot(numel(Sigma_list), 4, 4*i-1)
    plot(TpsP, Sig_r)
    title("Signal restoré")
    grid on, xlabel("Temps (s)"), ylabel("Amplitude")

    % fft débruité
    Sig_r_mod = abs(fftshift(fft(Sig_r, M)));

    % -- affichage
    subplot(numel(Sigma_list), 4, 4*i)
    plot(freq, Sig_r_mod)
    title("Domaine de Fourier")
    grid on, xlabel("Fréquences (Hz)"), ylabel("Amplitude")
end
set(gcf, "Position", get(gcf, "Position").*[1, 1, 3, 2])

%% == Partie 5 Filtrage == %%
% le signal à deux composantes (à obtenir)
Sig_cible = zeros(N, 1);
for i = 1:numel(fr)-1
    Sig_cible = Sig_cible + Alpha(i) * sin(2*pi*(fr(i)*TpsP+Phi));
end

% -- filtrage idéal : on met artificiellement à 0 les fréquences > 2kHz
Sig_ft = fftshift(fft(Sig, M));
freq = Fe * linspace(-0.5, 0.5, M);
Sig_ft(abs(freq) > 2000) = 0;       % mise à zéro
Sig_ideal = ifft(fftshift(Sig_ft)); % retour en spatial
Sig_ideal = Sig_ideal(1:N);         % extraction du signal
Sig_ideal = real(Sig_ideal);        % retire la partie imaginaire résiduelle

% -- filtrage convolutif : plus réaliste en pratique
% le filtre de réponse h
P = 10;
h = ((0:N-1)' < P)/P;
M = 32*N;
h_ft = fftshift(fft(h, M));
freq = Fe*linspace(-0.5, 0.5, M);
h_ft_th = sinc(P * freq / Fe);

% filtrage
Sig_ft = fftshift(fft(Sig, M));
Sig_filtre = ifft(fftshift(h_ft .* Sig_ft));
Sig_filtre = Sig_filtre(1:N);

% affichage du filtre et des fréquences à conserver/éliminer pour régler P
figure, hold on
plot(freq, abs(h_ft), "DisplayName", "FFT porte")
plot(freq, abs(h_ft_th), "DisplayName", "TF porte : sinc")
xline(-max(fr(1:2)), "--g", 'DisplayName', 'Fréquences à conserver');
xline(max(fr(1:2)), "--g", "HandleVisibility", "off");
xline(-fr(3), "--k", "DisplayName", "Fréquences à éliminer");
xline( fr(3), "--k", "HandleVisibility", "off");
xticks([-Fe/2, -fr(3), 0, fr(3), Fe/2])
legend, grid on, xlabel("Fréquence (Hz)"), ylabel("Amplitude")

% -- affichage des résultats
figure("Name", "4.2 Filtrage")
subplot(2, 2, 1), plot(TpsP, Sig), title("Ref : 3 composantes")
subplot(2, 2, 2), plot(TpsP, Sig_cible), title("Cible : 2 composantes")
subplot(2, 2, 3), plot(TpsP, Sig_ideal), title("Filtré idéal")
subplot(2, 2, 4), plot(TpsP, Sig_filtre), title("Filtré convolutif")
for i = 1:4
    subplot(2, 2, i), grid on, xlabel("Temps (s)"), ylabel("Amplitude")
    xlim([0, N/Fe])
end
set(gcf, "Position", get(gcf, "Position").*[1, 1, 2, 2])
