% ----------------------------------------------------------
% PeriodoGlissant.m	:	Fonction de calcul et trac� de specrogramme

% Declaration de la fonction.
	function PeriodoGlissant = NormSpec(Sig,Fe)

% Parametres d'analyse
	LongSig = size(Sig,1);
	LongFen = 512;
	LongSpec = 512;

% Trac� du signal
	Temps = (1:LongSig)/Fe;
	figure(1), clf
	subplot(211)
	plot(Temps,Sig)
	grid,axis([Temps(1) Temps(end) -0.6 0.6])

% On ne traite pas toutes les fenetres (Pour des questions de taille memoire)
	UnSurQ = 10;

% Decoupage
	MatSig = Decoupage(Sig,LongFen,UnSurQ);
	%clear Sig

% Calculs des periodogrammes
	Spec = abs(fft(MatSig , 2*LongSpec)).^2 / LongFen;
	Spec = Spec( 1:LongSpec/2 , : );
	clear MatSig

% Normalisation par le maximum ('M') ou par la puissance ('P') ou mM
	Spec = NormalSpec(Spec,'mM');

% Calcul des echelles frequentielles
	NuGri = linspace(0,1,LongSpec)*Fe/2;

% Calcul de l'axe des temps
	AxesTps = linspace(0,Temps(end),size(Spec,2));
	
% Trace des periodogrammes
	figure(1)
	subplot(212)
	imagesc(AxesTps,NuGri,Spec)	
	ylabel('Frequence (en Hertz)'),xlabel('Temps (en secondes)')

% Trace du  periodogramme global
	LePerio = (1/LongSig) * abs(fft(Sig)).^2;
	LePerio = LePerio(1:LongSig/2);
	NuGriSig = linspace(0,1,length(LePerio))*Fe/2;

	figure(2),clf
	subplot(211)
	plot(NuGriSig,LePerio)
	ylabel('Echelle lineaire'),grid on
	subplot(212)
	plot(NuGriSig,log10(LePerio))
	ylabel('Echelle Logarithmique'),grid on
	xlabel('Frequence (en Hertz)')


% ----------------------------------------------------------
% NormalSpec.m	:	Fonction de normalisation des spectres.

% Declaration de la fonction.
	function Spec = NormalSpec(Spec,Option)

% Parametres
	LongSpec = size(Spec,1);

% Normalisation par le maximum
if Option=='M'
	Max = max(Spec);
	Spec = Spec ./ Max(ones(LongSpec,1),:);
end

% Normalisation par le min et le max
if Option=='mM'
	Max = max(Spec);
	Min = min(Spec);
	Spec = (Spec - Min(ones(LongSpec,1),:)) ./ (Max(ones(LongSpec,1),:)- Min(ones(LongSpec,1),:));
end

% Normalisation par la puissance
if Option=='P'
	Puiss = mean(Spec);
	Spec = Spec ./ Puiss(ones(LongSpec,1),:);
end

% ----------------------------------------------------------
%  Decoupage.m	:	Fonction de decoupage des signaux.

% Declaration de la fonction.
	function MatSig = Decoupage(Sig,LongFen,UnSurQ)


% Mise en colonne du signal
	Sig = Sig(:);


% Parametres des siganux a traiter
	LongSig  = size(Sig,1);
	

% Constructiuon de la matrice d'indice aui va bien
	Ind1 = (1:LongFen)';
	Ind2 = (0:UnSurQ:LongSig-LongFen);

	
% Construction de la matrices de signaux
	MatSig = Sig( Ind1(:,ones(1,size(Ind2,2))) + Ind2(ones(size(Ind1,1),1),:) );

% Mise a l'echelle
%	VectPuiss = sqrt( mean(abs(MatSig).^2) );
%	MatSig = MatSig ./ VectPuiss(ones(LongFen,1),:);
%	VectPuiss = mean(abs(MatSig).^2);
