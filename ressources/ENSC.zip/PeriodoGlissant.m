% TP ENSC 1A
% PM edit: 13/05/2025
function PeriodoGlissant(Sig, Freq)
    % Taille du segment et du recouvrement
    windowLength = 256; % Longueur de la fen�tre (par exemple)
    overlapLength = 128; % Recouvrement entre les fen�tres
    nfft = 1024; % Nombre de points pour la FFT

    % Fen�tres de Hamming
    window = hamming(windowLength);

    % Calcul du p�riodogramme de Welch
    [Pxx, f] = pwelch(Sig, window, overlapLength, nfft, Freq);

    % Affichage du r�sultat
    figure;
    plot(f, 10*log10(Pxx)); % Affichage en dB
    title('P�riodogramme de Welch');
    xlabel('Fr�quence (Hz)');
    ylabel('Densit� spectrale de puissance (dB/Hz)');
    grid on;
end
