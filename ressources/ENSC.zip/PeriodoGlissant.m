% TP ENSC 1A
% PM edit: 13/05/2025
% remarque : ce n'est pas un periodo(gramme) mais un spectrogramme...
function PeriodoGlissant(Sig, Freq)
    % Sig : signal temporel d'entr�e
    % Freq : fr�quence d'�chantillonnage du signal
    window_length = 256; % taille de la fen�tre
    overlap = 0.5; % recouvrement de 50%
    
    % Param�tres
    hop_size = floor(window_length * (1 - overlap)); % taille du pas entre les fen�tres
    n_windows = floor((length(Sig) - window_length) / hop_size) + 1; % nombre de fen�tres
    
    % Fr�quences de la FFT
    nfft = 2^nextpow2(window_length);
    freqs = (0:nfft-1) * (Freq / nfft);

    % Matrice pour stocker les r�sultats de la FFT pour chaque fen�tre
    spectrogramme = zeros(nfft, n_windows); 
    
    % Calculer le spectrogramme
    for i = 1:n_windows
        start_idx = (i - 1) * hop_size + 1;
        window = Sig(start_idx:start_idx + window_length - 1);
        fft_result = fft(window, nfft);
        spectrogramme(:, i) = abs(fft_result);
    end

    % Temps de chaque fen�tre (en secondes)
    time_instants = (0:n_windows-1) * hop_size / Freq; 

    % Affichage
    figure;
    imagesc(time_instants, freqs, 10*log10(spectrogramme));  % en dB
    axis xy;
    xlabel('Temps (s)');
    ylabel('Fr�quence (Hz)');
    title('Spectrogramme');
    colorbar;
end
