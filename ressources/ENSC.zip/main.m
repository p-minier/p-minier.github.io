%% Initialisation
clc, clear, close all

%% Définition des constantes
fr = [440, 460, 2500]; % fréquences des raies en Hz
Alpha = [1.2, 1.2, 0.6]; % amplitude des raies
Fe = 1e4;  % fréquence d'échantillonnage en Hz
Phi = 0.27;
N = 1024;

%% Partie 1: Simulation de signaux
% Création du signal
TpsD = (0:N-1).';
TpsP = TpsD / Fe;
Sig = Alpha(1) * sin(2*pi*(fr(1)*TpsP+Phi));

% Check format données
str = ["colonne", "ligne"];
disp("TpsD est une " + str(1+isrow(TpsD)) + ".");
disp("Sig est une " + str(1+isrow(Sig)) + ".");

% Tracé du signal
figure
Tps = [TpsD, TpsP];
xlabel_ = ["Temps (itérations)", "Temps (seconde)"];
for i = 1:2
subplot(2, 1, i)
    plot(Tps(:, i), Sig)
    grid
    title("Signal")
    xlabel(xlabel_(i))
end

% Signal enrichi
for i = 2:numel(fr)
    Sig = Sig + Alpha(i) * sin(2*pi*(fr(i)*TpsP+Phi));
end

% Netoyage
clearvars i str xlabel_

%% Partie 2: Transformée de Fourier
% Transformée
Nfft = 32*N;  % nombre de fréquences à évaluer
Sig_ft = fftshift(fft(Sig, Nfft));
freq.reduite  = linspace(-0.5, 0.5, Nfft);
freq.physique = freq.reduite * Fe;

% Affichage
figure
subplot(2, 2, 1); plot(freq.physique, real(Sig_ft));
subplot(2, 2, 2); plot(freq.physique, imag(Sig_ft));
subplot(2, 2, 3); plot(freq.physique, abs(Sig_ft));
subplot(2, 2, 4); plot(freq.physique, log10(abs(Sig_ft)));
title_ = ["Réel", "Imaginaire", "Module", "Log10 Module"];
for i = 1:4
    ax1 = subplot(2, 2, i);
    grid on
    xlabel("Fréquence (Hz)")
    ylabel("Amplitude")
    title(title_(i))
end

%% Evaluation de la précision des pics selon M
M_pow = 0:10;
M_list = N*(2.^M_pow);
freq_true = [440, 460, 2500];
N_freq = 3;

freq_found = NaN(numel(M_list), N_freq);
for i = 1:numel(M_list)
    M = M_list(i);
    freq = Fe*linspace(-0.5, 0.5, M);
    Sig_ft = fftshift(abs(fft(Sig, M)));
    maxloc = islocalmax(Sig_ft, "MaxNumExtrema", 2*numel(freq_true));
    freq_max = freq(maxloc);
    freq_pos = freq_max(freq_max > 0);
    freq_found(i, :) = sort(freq_pos);
end
figure
for i = 1:N_freq
    subplot(2, 2, i)
    hold on
    plot(freq_found(:, i), "-o", "LineWidth", 2)
    yline(freq_true(i), "LineWidth", 1.5)
    grid
    ylim([min(min(freq_found(:, i)), freq_true(i)-1), max(max(freq_found(:, i)), freq_true(i)+1)]);
    if i == 1
        legend({"Détecté", "Vraie"}, 'Location', 'best');
    end
    ylabel("Hz")
    title("Pic " + num2str(i))
end
sgtitle("Précision des pics retrouvés selon M = log2(Nfft/N)");

%% Périodogramme
[Sig_j, Freq_j] = audioread("Joli.wav");
PeriodoGlissant(Sig_j, Freq_j);

%% Bruitage et débruitage
Sig = Alpha(1) * sin(2*pi*(fr(1)*TpsP+Phi));
Sigma_list = [0.5, 1, 10];
M = 32*N;
freq_ax = Fe * linspace(-0.5, 0.5, M);
figure
for i = 1:numel(Sigma_list)
    % bruitage du signal
    SigmaBruit = Sigma_list(i);
    Bruit = SigmaBruit * randn(size(Sig));
    Sig_b = Sig + Bruit;

    RSB = 10*log10(sum(Sig.^2) / sum(Bruit.^2));
    RSB = round(RSB, 3);

    % fft
    Sig_b_fft = fftshift(fft(Sig_b, M));
    Sig_b_mod = abs(Sig_b_fft);

    % affichages
    subplot(numel(Sigma_list), 2, 2*i-1)
    plot(TpsP, Sig_b)
    title("Signal temporel, RSB = " + RSB)
    grid on, xlabel("Temps (s)"), ylabel("Amplitude")

    subplot(numel(Sigma_list), 2, 2*i)
    plot(freq_ax, Sig_b_mod)
    title("Domaine de Fourier")
    grid on, xlabel("Fréquences (Hz)"), ylabel("Amplitude")
end

%% débruitage par décomposition en valeurs propres
clc, close all

%% bruitage du signal
SigmaBruit = Sigma_list(1);
Bruit = SigmaBruit * randn(size(Sig));
Sig_b = Sig + Bruit;

% valeurs propres
[U,S,V] = svd(Sig_b);

% Affichage des valeurs propres
figure
stem(S)
grid

%%

% reconstruction
Sig_r = U(:, 1) * diag(S(1)) * V(:, 1)';

%%
Sig_to_plot = {Sig, Sig_b, Sig_r};
titles_ = {"Signal", "Observation", "Reconstruction"};
figure
hold on
for i = 1:3
    subplot(3, 1, i)
    plot(TpsP, Sig_to_plot{i})
    title(titles_{i})
end

