./bin/kmean data/donuts.csv 2
./bin/kmean data/lunes.csv  2
./bin/kmean data/globes.csv 3
./bin/kmean data/lignes.csv 3
./bin/kmean data/exp.csv 3

./bin/dsbcan data/donuts.csv .5  10
./bin/dsbcan data/lunes.csv  .6  10
./bin/dsbcan data/globes.csv .85 10
./bin/dsbcan data/lignes.csv .71 10
