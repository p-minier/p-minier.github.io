#ifndef TEST_H_
#define TEST_H_

void print_cloud(cloud_t* cloud);
#endif